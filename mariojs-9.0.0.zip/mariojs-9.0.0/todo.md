## Todo List
[*] Preloading sprites and Sky
[*] Creating Mario and Game Loop
[*] Controlling Mario 
[*] Adding Gravity
[*] Mario Animation  
[*] Adding Background 
[] Creating Enemies
    [*] Creating Goomba
    [] Creating Goomba
[] Adding collision b/w different Entities
[] Adding coins 
[] Adding Bricks
[] Adding Mushroom
[] Finishing Game Logic and sound