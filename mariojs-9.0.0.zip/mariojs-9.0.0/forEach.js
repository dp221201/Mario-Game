let arr=[1,2,3,4,5];
function print(x){
console.log(2*x);
}
arr.forEach(print);