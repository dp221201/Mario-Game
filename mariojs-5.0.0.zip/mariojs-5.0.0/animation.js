let animation={
    update(gameObj){
let mario=gameObj.entities.mario;
mario.currentState(gameObj);

    }
}