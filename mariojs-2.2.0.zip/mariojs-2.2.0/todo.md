## Todo List
[*] Preloading sprites and Sky
[*] Creating Mario and Game Loop
[*] Controlling Mario 
[] Adding Gravity
[] Adding Background
[] Mario Animation and sound
[] Creating Enemies
[] Adding collision b/w different Entities
[] Adding coins 
[] Adding Bricks
[] Finishing Game Logic